
use(function () {
  var myproperty = properties.get("https://www.hogan.com/ww-en/store-locator.html?gl=en_ww");
  return {callajaxvariable: myproperty};
});