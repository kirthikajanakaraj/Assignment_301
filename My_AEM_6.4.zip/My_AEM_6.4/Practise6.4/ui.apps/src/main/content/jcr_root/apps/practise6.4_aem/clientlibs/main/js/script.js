
$(document).ready(function(){
 
     $('body').hide().fadeIn(1000);
    $('#submit').click(function() {
 
 
 
      //read the values
        var myName = $('#first').val(); 
        var myemail = $('#email').val(); 
 
 
 
        //alert(myemail) ; 
 
 
 
    //Perform an AJAX operation
        $.ajax({
type: 'POST', 
url:'/bin/myDataSourcePoolServlet',
data:'firstName='+ myName+'&email='+ myemail,
success: function(msg){
    alert(msg); //display the data returned by the servlet
}
});
 
 
 
 
});
});