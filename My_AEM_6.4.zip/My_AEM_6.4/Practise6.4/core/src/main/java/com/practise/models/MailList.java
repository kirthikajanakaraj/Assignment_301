package com.practise.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
  
import javax.annotation.PostConstruct;
import javax.inject.Inject;
  
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
  
  
@Model(adaptables = Resource.class)
public class MailList {
  
    private final Logger LOG = LoggerFactory.getLogger(getClass());
  
    @Inject @Optional
    public String text; // corresponds to the node in the dialog named text
     
     
    @Inject @Optional
    public String heading; // corresponds to the node in the dialog named heading
     
    private String myText ; 
     
    private String myHeading ; 
  
       
    @PostConstruct
    protected void init() {
        LOG.info("Dialog Text is  **** "+ text);
        myText = text; 
        myHeading = heading ; 
    }
  
    public String getText() {
        return myText;
    }
     
     
    public String getHeading() {
        return myHeading;
    }
    
    
}