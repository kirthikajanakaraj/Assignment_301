package com.practise.schudler;

import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;

@ObjectClassDefinition(name = "Test Scheduler")
public @interface SchedulerInterface {

	@AttributeDefinition(name = "Meassage", description = "Message to be displayed !!")
	String schdulerName() default "Hi, Welcome to 2020";

	@AttributeDefinition(name = "Scheduler Expression - 6.4", description = "Enter the CRON Expression here.. No need to go for Backend(Java)")
	String scheduler_expression() default "0/30 0/1 * 1/1 * ? *";
}
