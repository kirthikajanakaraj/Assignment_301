package com.practise.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Optional;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.json.JSONArray;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.ConfigurationPolicy;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.metatype.annotations.AttributeDefinition;
import org.osgi.service.metatype.annotations.Designate;
import org.osgi.service.metatype.annotations.ObjectClassDefinition;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;

@Component(service = Servlet.class, property = { "sling.servlet.extensions=json",
		"sling.servlet.paths=/bin/jsonservlet",
		"sling.servlet.methods=get" }, configurationPolicy = ConfigurationPolicy.REQUIRE, immediate = true)
@Designate(ocd = JsonServlet.Configurations.class)
public class JsonServlet extends SlingSafeMethodsServlet {

	private static final long serialVersionUID = 1L;
	private static final Logger log = LoggerFactory.getLogger(JsonServlet.class);

	public static java.util.List<PageBean> links = new ArrayList<PageBean>();
	private String nodePath;
	Resource resource;
	PrintWriter out;

	@ObjectClassDefinition(name = "JSON Demo Servlet")
	public @interface Configurations {
		@AttributeDefinition(name = "Enter Path", description = "Page or node path")
		String getPath() default "/content/we-retail/language-masters/en";

		@AttributeDefinition(name = "Cron Expression", description = "Schudlure Expression")
		String scheduler_expression() default "0/30 0/1 * 1/1 * ? *";

	}

	@Override
	protected void doGet(final SlingHttpServletRequest request, final SlingHttpServletResponse response)
			throws ServletException, IOException {
		if (nodePath != null) {
			ResourceResolver resourceResolver = request.getResourceResolver();
			resource = resourceResolver.resolve(nodePath);
			out = response.getWriter();
			out.write("\n DOGET========>" + buildLinks());
			log.info("SChuduler is Running");
			System.out.println("Schuduler is Running");

		}

	}

	public String buildLinks() {
		if (resource != null) {
			Iterator<Resource> linkResources = resource.listChildren();
			linkResources.forEachRemaining(res -> populateModel(res).ifPresent(links::add));
		}
		String jsonData = buildJson();
		return jsonData;
	}

	public Optional<PageBean> populateModel(Resource resource) {

		PageBean link = new PageBean();
		Page page = resource.adaptTo(Page.class);
		if (page != null) {
			link.setTitle(page.getTitle());
			link.setPath(page.getPath());
		}
		out.println("LINK::::::" + link.toString());
		return Optional.of(link);
	}

	public String buildJson() {
		out.println("JSON::::::::" + links.toString());
		JSONArray json = new JSONArray(links);
		return json.toString();
	}

	@Activate
	@Modified
	protected void Activate(Configurations config) {
		nodePath = config.getPath();
	}

}