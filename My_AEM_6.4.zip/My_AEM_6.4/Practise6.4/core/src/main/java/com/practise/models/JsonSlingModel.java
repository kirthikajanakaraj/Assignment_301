package com.practise.models;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.json.JSONArray;

import com.practise.schudler.JsonInterface;

@Model(adaptables = Resource.class)
public class JsonSlingModel {
	@OSGiService
	JsonInterface ji;
	private String jsonstring;
	
	@PostConstruct
	public void displayjson()
	{
		System.out.println("Sling JSONArray!!!"+ji.getjson().toString());
		JSONArray getjson = ji.getjson();
		jsonstring = getjson.toString();
		
	}

	public String getJsonstring() {
		return jsonstring;
	}

	
	
	
}
