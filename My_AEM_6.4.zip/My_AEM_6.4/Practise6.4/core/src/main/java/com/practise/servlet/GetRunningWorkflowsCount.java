package com.practise.servlet;

import java.io.IOException;
import java.lang.management.ManagementFactory ;
import java.rmi.ServerException;
import java.util.Set;

import javax.management.MBeanServer ;
//import MBean API
import javax.management.MBeanServerConnection;
import javax.management.ObjectName;
import javax.servlet.Servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.HttpConstants;
import org.osgi.framework.Constants;
//DS Annotations
import org.osgi.service.component.annotations.Component;
   
    
@Component(service=Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Simple Demo Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_GET,
                "sling.servlet.resourceTypes="+ "mbean64/components/structure/page",
                "sling.servlet.selectors=" + "workflow"
        })
public class GetRunningWorkflowsCount extends org.apache.sling.api.servlets.SlingAllMethodsServlet {
     private static final long serialVersionUID = 2598426539166789515L;
         
            
                   
     @Override
     protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServerException, IOException {
          
      try
      {
           
           //Create a MBeanServer class
          MBeanServer server = ManagementFactory.getPlatformMBeanServer();
  
          ObjectName workflowMBean = getWorkflowMBean(server);
  
          //Get the number of stale workflowitems from AEM
          Object staleWorkflowCount = server.invoke(workflowMBean, "countRunningWorkflows", new Object[]{null}, new String[] {String.class.getName()});
  
          int mystaleCount = (Integer)staleWorkflowCount; 
                  
          //Return the number of stale items 
          response.getWriter().write("There are "+mystaleCount +"  running workflows");
           
                  // response.getWriter().write("The Servlet works");
           
      }
      catch(Exception e)
      {
          e.printStackTrace();
      }
    }
        
        
     private static ObjectName getWorkflowMBean(MBeanServerConnection server)
     {
         try
         {
         Set<ObjectName> names = server.queryNames(new ObjectName("com.adobe.granite.workflow:type=Maintenance,*"), null);
           
         if (names.isEmpty()) {
                 return null;
         }
  
         return names.iterator().next();
         }
         catch(Exception e)
         {
             e.printStackTrace();
         }
         return null; 
}
  
        
}
