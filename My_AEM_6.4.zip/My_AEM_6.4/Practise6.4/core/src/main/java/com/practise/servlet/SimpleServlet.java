package com.practise.servlet;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.servlets.HttpConstants;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.apache.sling.api.resource.ValueMap;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import javax.servlet.Servlet;
import javax.servlet.ServletException;
import java.io.IOException;
 
//Add the DataSourcePool package
import com.day.commons.datasource.poolservice.DataSourcePool; 
 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
 
 
import java.sql.SQLException;
import javax.sql.DataSource;
 
/**
 * Servlet that writes some sample content into the response. It is mounted for
 * all resources of a specific Sling resource type. The
 * {@link SlingSafeMethodsServlet} shall be used for HTTP methods that are
 * idempotent. For write operations use the {@link SlingAllMethodsServlet}.
 */
@Component(service=Servlet.class,
        property={
                Constants.SERVICE_DESCRIPTION + "=Simple Demo Servlet",
                "sling.servlet.methods=" + HttpConstants.METHOD_POST,
                "sling.servlet.paths="+ "/bin/myDataSourcePoolServlet"
           })
public class SimpleServlet extends SlingAllMethodsServlet {
 
    private static final long serialVersionUid = 1L;
     
    private final Logger logger = LoggerFactory.getLogger(getClass());
     
    @Reference
    private DataSourcePool source;
 
    @Override
    protected void doPost(final SlingHttpServletRequest req,
            final SlingHttpServletResponse resp) throws ServletException, IOException {
        
        try
        {
           //Get the submitted data from the Email Signup component  
            String firstName = req.getParameter("firstName");
            String email = req.getParameter("email");
         
        //Persist the Data into MySQL
         int yy =    injestCustData(firstName, email) ; 
         
          
         logger.info("****** THe YY value is "+yy); 
          
             
        resp.setContentType("text/plain");
        resp.getWriter().write(email);
     
        }
        catch (Exception e)
        {
            e.printStackTrace(); 
        }
                 
        }
  
          
   
//Returns a connection using the configured DataSourcePool 
  private Connection getConnection()
  {
           DataSource dataSource = null;
           Connection con = null;
           try
           {
               //Inject the DataSourcePool right here! 
               dataSource = (DataSource) source.getDataSource("Customer");
               con = dataSource.getConnection();
               return con;
                
             }
           catch (Exception e)
           {
               e.printStackTrace(); 
           }
               return null; 
  }
    
  public int injestCustData(String name, String email) {
      Connection c = null;
        
      int rowCount= 0; 
      try {
                       
            // Create a Connection object
            c =  getConnection();
          
             ResultSet rs = null;
             Statement s = c.createStatement();
             Statement scount = c.createStatement();
                
             //Use prepared statements to protected against SQL injection attacks
             PreparedStatement pstmt = null;
             PreparedStatement ps = null; 
                          
             int pk =  getPK();      
              
             logger.info("****** THe PK IS is "+pk); 
              
             String insert = "INSERT INTO customer(idcustomer, name,email) VALUES(?, ?, ?);";
             ps = c.prepareStatement(insert);
              
             ps.setInt(1,pk); 
             ps.setString(2, name);
             ps.setString(3, email);
             ps.execute();
             return 0;
      }
      catch (Exception e) {
        e.printStackTrace();
       }
      finally {
        try
        {
          c.close();
        }
         
          catch (SQLException e) {
            e.printStackTrace();
          }
  }
      return -1; 
}
 
    private int getPK()
    {
         
        //generate an example PK
        java.util.Random r = new java.util.Random();
        int Low = 10;
        int High = 40000;
        int Result = r.nextInt(High-Low) + Low;
         
        return Result; 
    }
   
}

