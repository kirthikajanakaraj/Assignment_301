package com.practise.models;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;
import org.json.JSONArray;

@Model(adaptables = Resource.class)
public class JsonModel 
{

	 String jsonObject;
	    
	    @PostConstruct
	    private void init() {
	        
	        Map<String, Object> map = new HashMap<String, Object>();
	        map.put("Course", "AEM");
	        map.put("Duration", "One month");
	        map.put("AssignedBy", "Murudula");
	        map.put("Mentor","Vipin");
	        
	        List<Map<String, Object>> list = new ArrayList<Map<String,Object>>();
	        list.add(map);
	        
	        JSONArray json = new JSONArray(list);
	        jsonObject = json.toString();
	        System.out.println("JSON_VALUE"+jsonObject);
	        
	    }

		public String getJsonObject() {
			return jsonObject;
		}
	
	
}
