package com.practise.schudler;

import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true,service=JsonInterface.class)
@Designate(ocd = SchedulerInterface.class)
public class SampleScheduler implements Runnable,JsonInterface {

	private static final Logger log = LoggerFactory.getLogger(SampleScheduler.class);

	private String schdulerName;
	private JSONArray jsArray;


	@Activate
	public void Scheduler(SchedulerInterface test) {
		this.schdulerName = test.schdulerName();
	}

	@Override
	public void run() {

		log.info("SchdulerName" + schdulerName);
		System.out.println("SchulerName"+schdulerName);
		Map<String, String> map = new HashMap<String, String>();
		map.put("Course", "AEM");
		map.put("Period", "1 month");
		
		try {
			jsArray = new JSONArray(map);
//			json = jsArray.toString();
			log.info("JSONDATA::::::::::" + jsArray.toString());
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public JSONArray getjson() {
		// TODO Auto-generated method stub
		return jsArray;
	}

}