package com.practise.schudler;

import org.apache.sling.commons.scheduler.ScheduleOptions;
import org.apache.sling.commons.scheduler.Scheduler;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.metatype.annotations.Designate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component(immediate = true, service = SampleScheduler.class)
@Designate(ocd = SchedulerInterface.class)
public class SampleScheduler implements Runnable {

	private static final Logger log = LoggerFactory.getLogger(SampleScheduler.class);

	private String customParameter;

	private int schedulerId;

	@Reference
	private Scheduler scheduler;

	@Activate
	protected void activate(SchedulerInterface config) {

		schedulerId = config.schdulerName().hashCode();

		customParameter = config.customParameter();
	}

	@Modified
	protected void modified(SchedulerInterface config) {

		removeScheduler();

		schedulerId = config.schdulerName().hashCode();

		addScheduler(config);
	}

	@Deactivate
	protected void deactivate(SchedulerInterface config) {

		removeScheduler();
	}

	private void removeScheduler() {

		log.info("Removing scheduler: {}", schedulerId);

		scheduler.unschedule(String.valueOf(schedulerId));
	}

	private void addScheduler(SchedulerInterface config) {

		if (config.enabled()) {

			ScheduleOptions scheduleOptions = scheduler.EXPR(config.cronExpression());

			scheduleOptions.name(config.schdulerName());
			scheduleOptions.canRunConcurrently(false);

			scheduler.schedule(this, scheduleOptions);

			log.info("Scheduler added");

		} else {

			log.info("Scheduler is disabled");

		}
	}

	@Override
	public void run() {

		log.info("Custom Scheduler is now running using the passed custom paratmeter, customParameter {}",
				customParameter);

	}

}