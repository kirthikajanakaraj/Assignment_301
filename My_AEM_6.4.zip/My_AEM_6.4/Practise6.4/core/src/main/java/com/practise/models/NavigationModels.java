package com.practise.models;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;

import com.day.cq.wcm.api.Page;
import com.practise.services.NavigationService;

@Model(adaptables = Resource.class)
public class NavigationModels {
	
	@Inject
	private ResourceResolver resolver;
	
	@Inject @Optional                       
	private String pagePath;
	
	@Inject@Optional
	private String pagePath1;
	
	@OSGiService
	private NavigationService navigation;
	
	private List<Page> childPageList;
	
	private List<Page>childPageList1;
	
	@PostConstruct
	private void init() {
		childPageList = navigation.getChildPages(resolver, pagePath);
		childPageList1=navigation.getChildPages(resolver, pagePath1);
	}

	public List<Page> getChildPageList() {
		return childPageList;
	}

	public List<Page> getChildPageList1() {
		return childPageList1;
	}

	
}
