package com.practise.services;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.Model;

@Model(adaptables = Resource.class)
public class Distance {

	private String codecountry;
	private String fullcountry;

	public void setCountry(String fullcountry) {
		this.fullcountry = fullcountry;
	}

	public String getCountry() {
		return this.fullcountry;
	}

	public void setCode(String codecountry) {
		this.codecountry = codecountry;
	}

	public String getCode() {
		return this.codecountry;
	}

}
