package com.practise.schudler;

import org.json.JSONArray;

public interface JsonInterface {
	JSONArray getjson();
}
