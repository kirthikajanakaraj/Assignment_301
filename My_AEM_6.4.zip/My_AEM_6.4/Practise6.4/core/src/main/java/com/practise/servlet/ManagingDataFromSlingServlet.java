package com.practise.servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Servlet;
import javax.servlet.ServletException;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingAllMethodsServlet;
import org.apache.sling.jcr.api.SlingRepository;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

import com.google.gson.JsonArray;

@Component(service = Servlet.class, property = { "sling.servlet.paths=/bin/mySearchServlet",
		"sling.servlet.methods=GET/POST" }, immediate = true)
public class ManagingDataFromSlingServlet extends SlingAllMethodsServlet {
	private static final long serialVersionUID = 1L;

	@Reference
	SlingRepository repository;

	public void bindRepository(SlingRepository repository) {
		this.repository = repository;
	}

	@Override
	protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().write("Servlet is Brgin!!!");
		String id = UUID.randomUUID().toString();
		String firstname = request.getParameter("firstname");
		String lastname = request.getParameter("lastname");
		String address = request.getParameter("address");
		String cat = request.getParameter("cat");
		String state = request.getParameter("state");
		String details = request.getParameter("details");
		String date = request.getParameter("date");
		String city = request.getParameter("city");

		JsonArray jsarray = new JsonArray();
		jsarray.add(id);
		jsarray.add(firstname);
		jsarray.add(lastname);
		jsarray.add(address);
		jsarray.add(cat);
		jsarray.add(state);
		jsarray.add(details);
		jsarray.add(date);
		jsarray.add(city);
		String jsondata = jsarray.toString();
		response.getWriter().write("JSONDATA" + jsondata);

	}

}
